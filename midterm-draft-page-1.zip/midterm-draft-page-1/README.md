# Midterm Draft page 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maddie-Jensen/pen/abxmRNm](https://codepen.io/Maddie-Jensen/pen/abxmRNm).

